<?php
require_once('db.php');
class DBGoods extends DB{
  //goodsテーブルのCRUD担当
  public function SelectGoodsAll(){
    $sql = "SELECT * FROM pokemon";
    $res = parent::executeSQL($sql, null);
    $data = "<table class='recordlist' id='goodsTable'>";
    $data .= "<tr><th>ID</th><th>商品名</th><th>単価</th><th></th><th></th></tr>\n";
    foreach($rows = $res->fetchAll(PDO::FETCH_NUM) as $row){
      $data .= "<tr>";
      for($i=0;$i<count($row);$i++){
        $data .= "<td>{$row[$i]}</td>";
      }
      //更新ボタンのコード
      $data .= <<<eof
      <td><form method='post' action=''>
      <input type='hidden' name='id' value='{$row[0]}'>
      <input type='submit' name='update' value='更新'>
      </form></td>
eof;
      $data .= "</tr>\n";
    }
    $data .= "</table>\n";
    return $data;
  }

  public function InsertGoods(){
    $sql = "INSERT INTO pokemon VALUES(?,?,?)";
    $array = array($_POST['id'],$_POST['name'],$_POST['love']);
    parent::executeSQL($sql, $array);
  }

  public function UpdateGoods(){
    $sql = "UPDATE pokemon SET name=?, love=? WHERE id=?";
    //array関数の引数の順番に注意する
    $array = array($_POST['name'],$_POST['love'],$_POST['id']);
    parent::executeSQL($sql, $array);
  }

  public function GoodsNameForUpdate($id){
    return $this->FieldValueForUpdate($id, "name");
  }

  public function PriceForUpdate($id){
    return $this->FieldValueForUpdate($id, "love");
  }

  private function FieldValueForUpdate($id, $field){
    //private関数　上の2つの関数で使用している
    $sql = "SELECT {$field} FROM pokemon WHERE id=?";
    $array = array($id);
    $res = parent::executeSQL($sql, $array);
    $rows = $res->fetch(PDO::FETCH_NUM);
    return $rows[0];
  }

  public function DeleteGoods($id){
    $sql = "DELETE FROM pokemon WHERE id=?";
    $array = array($id);
    parent::executeSQL($sql, $array);
  }
}
?>
