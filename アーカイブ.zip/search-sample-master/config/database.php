<?php

//DBの接続情報
$host = "localhost";
$username = "trainer";
$password = "redgreen";
$dbname = "sampledb";
