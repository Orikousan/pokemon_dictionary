﻿<?php
require_once('DBpokemon.php');
$dbGoods = new DBGoods();
//更新処理
if(isset($_POST['submitUpdate'])){
  $dbGoods->UpdateGoods();
}
//更新用フォーム要素の表示
if(isset($_POST['update'])){
  //更新対象の値を取得
  $dbid   = $_POST['id'];
  $dbname = $dbGoods->GoodsNameForUpdate($_POST['id']);
  $love     = $dbGoods->PriceForUpdate($_POST['id']);
  //クラスを記述することで表示/非表示を設定
  $entryCss = "class='hideArea'";
  $updateCss = "";
}else{
  $entryCss = "";
  $updateCss = "class='hideArea'";
}
//削除処理
if(isset($_POST['delete'])){
  $dbGoods->DeleteGoods($_POST['id']);
}
//新規登録処理
if(isset($_POST['submitEntry'])){
  $dbGoods->InsertGoods();
}
//テーブルデータの一覧表示
$data = $dbGoods->SelectGoodsAll();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>売上管理システム</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript">
function CheckDelete(){
    return confirm("削除してもよろしいですか？");
}
</script>
</head>
<body>
<div id="menu">
<ul>
<li><a href="search.php">ポケモン検索</a></li>
<li><a href="pokemon.php">お気に入り度変更</a></li>
</ul>
</div>
<h1>お気に入り度変更ー</h1>
<div id="entry" <?php echo $entryCss;?>>
<form action="" method="post">
<h2>新規登録</h2>
<label><span class="entrylabel">No.</span><input type='text' name='id' size="10" required></label>
<label><span class="entrylabel">名前</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">分類</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">属性</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">特性</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">高さ</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">重さ</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">生息地</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">説明</span><input type='text' name='name' size="30" required></label>
<label><span class="entrylabel">お気に入り度</span><input type='text' name='name' size="30" required></label>
<label>
  <span class="entrylabel">単価っっっっっm</span>
  <input type='text' name='love' size="10" required>
</label>
<input type='submit' name='submitEntry' value=' 　新規登録　 '>

</form>
</div>
<div id="update" <?php echo $updateCss;?>>
<form action="" method="post">
<h2>更新</h2>
<p>idあああ: <?php echo $dbid;?></p>
<input type="hidden" name="id" value="<?php echo $dbid;?>" />

<!-- <div>
		<label for="i_event">お申し込みされるイベント</label>
		<input id="i_event" type="text" name="event" value="第3回 読書会" readonly>
	</div> -->

<label><span class="entrylabel">ポケモン</span><input type='text' name='name'
 size="30" value="<?php echo $dbname;?>" readonly></label>
  -->
<label>
  <span class="entrylabel">お気に入り度</span>
  <select name='love'>
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
    <option>5</option>
  </select>
</label>

<!-- <input type="radio" name='Price' id="r1" value="1">
<label accesskey="N" for="r2">1(<u>2</u>)</label>
<input type="radio" name='Price' id="r2" value="2">
<label accesskey="N" for="r2">2(<u>2</u>)</label>
<input type="radio" name='Price' id="r3" value="3">
<label accesskey="N" for="r2">3(<u>2</u>)</label>
<input type="radio" name='Price' id="r4" value="4">
<label accesskey="N" for="r2">4(<u>2</u>)</label>
<input type="radio" name='Price' id="r5" value="5">
<label accesskey="N" for="r2">5(<u>2</u>)</label> -->


<input type='submit' name='submitUpdate' value=' 　更んん新　 '>
</form>
</div>
<div>
<?php echo $data;?>
</div>
</body>
</html>
