<?php
$comment = $_POST[‘name’];
echo $comment;
?>
<!DOCTYPE html>
<html lang = “ja”>
<head>
<meta charset = “UFT-8”>
<title>フォームからデータを受け取る</title>
</head>
<body>
<h1>フォームデータの送信</h1>
<form action = “list.php” method = “post”>
</form>
</body>
</html>
