<?php
    //データベースへ接続
    $dsn = "mysql:dbname=sampledb;host=localhost;charset=utf8mb4";
    $username = "trainer";
    $password = "redgreen";
    $options = [];
    $pdo = new PDO($dsn, $username, $password, $options);
        if(@$_POST["id"] != "" OR @$_POST["user_name"] != ""){ //IDおよびユーザー名の入力有無を確認
            $stmt = $pdo->query("SELECT * FROM user_list WHERE ID='".$_POST["id"] ."' OR Name LIKE  '%".$_POST["user_name"]."%')"); //SQL文を実行して、結果を$stmtに代入する。
        }
?>
<!DOCTYPE html>
<html lang = “ja”>
<head>
<meta charset = “UFT-8”>
<title>フォームからデータを受け取る</title>
</head>
<body>
<h1>フォームデータの送信</h1>
<form action = “list.php” method = “post”>
</form>
    <table>
    <tr><th>ID</th><th>User Name</th></tr>
    <!-- ここでPHPのforeachを使って結果をループさせる -->
    <?php foreach ($stmt as $row): ?>
        <tr><td><?php echo $row[0]?></td><td><?php echo $row[1]?></td></tr>
    <?php endforeach; ?>
</table>
</body>
</html>
